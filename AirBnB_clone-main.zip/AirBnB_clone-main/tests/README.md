# Python Unittest Model
The project utilizes the python unittest model to ensure the functionalities of its models. The following sample script runs a test model: ```python -m unittest tests/```