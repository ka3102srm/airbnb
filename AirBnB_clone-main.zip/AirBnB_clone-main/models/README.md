# The Console's Models
This model contains implementations for basic functional methods for the console's model